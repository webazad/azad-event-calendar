export { default } from './component';
